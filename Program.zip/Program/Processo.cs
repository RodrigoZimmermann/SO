﻿namespace Program
{
    public class Processo
    {
        public string nome { get; set; }
        public int tempo { get; set; }
    }
}
